require "application_system_test_case"

class ItemsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit items_url
  #
  #   assert_selector "h1", text: "Item"
  # end
end
